# Property Marketplace — V2

Mobile-first Nigerian property marketplace frontend.

## What's new
- Featured property listings shown prominently after search
- Latest/sample listings with realistic property details
- Property cards with photos, price, location, beds, baths and size
- Save/favourite button UI
- View Property button and detail modal
- Search and category filtering
- Demo listing labels to avoid implying that sample properties are live or verified
- Free listing / optional paid promotion messaging

## Note
The current listings are demo data. Database-backed listings, real agent accounts, image uploads, WhatsApp enquiries and inspection requests are planned for later phases.
